import cv2 as cv

class PH:
    Name = 0
    img = 0

    def __new__(self, name, image):
        self.Name = name
        self.img = image

    def getname(self):
        return  self.Name

    def getimage(self):
        return self.img
